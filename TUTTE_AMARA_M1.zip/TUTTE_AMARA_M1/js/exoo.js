


var equatio="";
function hello(T){
  

   
        


var p=0;
var lo=T.length;
var re=0;
var pui=Math.pow(2, lo);
var mat= new Array();
var comp=new Array();
nbsom=sommetotal(T).length;

  var m=0;

for(var i=0;i<pui;i++){
  var s = (i-0).toString(2);
  re=s.split("");
  for(var j=0;j<re.length;j++){
    if (!mat[i])
    mat[i] = new Array(); 
    mat[i][j] = re[j];
  }
  re=0,s=0;
}
var tab="";
var l="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
var al=l.split("");
var pro=[];
for(var i=0;i<pui;i++){
  p=0;
  tab="";
for(var j=(mat[i].length-1);j>=0;j--){
  if(mat[i][j]==1){
    tab=al[p]+tab;
    p=p+1;
  }else{p=p+1;}
}
pro[i]=tab;
}
//alert(l.indexOf("")+"  fff   "   +T[0]);
//alert(pro);
var fin=[];
var rels=[];
var spp=0,k=0;
var get=0;
var max="";
for(var i=1;i<pro.length;i++){
   spp=pro[i].split("");
     max="";
     k=0;
     fin.splice(0,6);
        for(var j=0;j<spp.length;j++){
            get=l.indexOf(spp[j]);
            //if(!(max.includes(T[get])))
             fin[k]=T[get];
             k=k+1;
 }

//alert(fin+"   get "+T.length);

relation_coupure(nbsom,fin);
//fin.splice(0,5);
//alert(rels);
}
function sommetotal(T){
  var to="";
for(var i=0;i<T.length;i++)
  to=to+T[i];
  mp=to.split("");
  nbs=cleanArray(mp);
  return nbs;
}
function cleanArray(array) {
  var i, j, len = array.length, out = [], obj = {};
  for (i = 0; i < len; i++) {
    obj[array[i]] = 0;
  }
  for (j in obj) {
    out.push(j);
  }
  return out;
}
function relation_coupure(Nbsom,rnf){
var j=0,x=0,a=0,d=0,cou=0,s=0,v=0,arccc;
var b,ret="";
var haz=new Array();
var arc=new Array();
var k=new Array();
var cf=new Array();
var ta=new Array();
//var tab="ab";
//alert(rnf[0]+"   "+fin[0])
testo(rnf[0]);
function testo(tab){
  ta=tab.split("");
  j=0;
  while(typeof(rnf[j])!='undefined'){
    //alert(rnf);
    b=0;
    for(var i=0;i<ta.length;i++){
      if(typeof(rnf[j])!='undefined'){
        if(rnf[j].includes(ta[i])){
                cf=rnf[j].split("");
                for(var l=0;l<cf.length;l++){
                  if(!arc.includes(cf[l])){
                  arc=cf[l]+arc;
                  d=d+1;}
                  }
                  b=5;
                  rnf.splice(j,1);}}
      //  }
    }
    if((b!=5)&&(rnf.length!=0)){j=j+1;}
  
  }  
 // alert(arccc+ " dif "+arc);

if(arccc==arc){
  if(rnf.length!=0){
    haz=hazar(rnf[0]);
    x=x+arc.length; // ya du travaille par la gros
    a=a+1;
    //alert("aaaa" +a)
    arc="";
    testo(haz);

}}
//alert("rnf le "+rnf.length);
if((rnf.length==0)&&(v!=3)){
  //alert("c fini");
 // alert(arc);
 a=a+1;
 x=x+arc.length;
 //alert("coupur "+a);
 comp[m]=Nbsom-x+a;
 //alert("mm "+m)
 //alert(x+"  "+a);
 //alert("nombre composant connexe : "+comp);
  m=m+1;
  v=3;

}else if(v!=3){
  arccc=arc;
  testo(arc);
}

}
function hazar(cho){
  ret="";
k=cho.split("");
for(var i=0;i<k.length;i++){
  ret=k[i]+ret;
}
return ret;
}

function extrai(cf){
  f=cf.split()
}

}
//alert(comp);
//alert(pro.length+"     "+comp.length);
var Y= new Array();
var X=new Array();
var YY= new Array();
var XX=new Array();
var r=0,pl=0;
X[r]=nbsom-1;
Y[r]=0;
for(var i=0;i<comp.length;i++){
r=r+1;
X[r]=comp[i]-comp[comp.length-1];
Y[r]=pro[r].length+comp[i]-nbsom;
}
var x;

var matrix = [];
matrix_0(nbsom,nbsom);

for(var i=0;i<X.length;i++){

 eqx=calcux(X[i]);////
 eqy=calcuy(Y[i]);
 //alert(eqx[0]+" c "+eqy)
 //conv_tab(eqx);
if((eqx[0].includes("x^0"))&&(eqy[0].includes("y^0"))){
 //alert("x0 et y0");
 nch_insert("1","1",matrix);


}
  else{if((eqx[0].includes("x^0"))&&!(eqy[0].includes("y^0"))){
//alert("x0 et yn");
nch_insert("1",eqy,matrix);

  }
   else{ if(!(eqx[0].includes("x^0"))&&(eqy[0].includes("y^0"))){
//alert("xn et y0");
nch_insert(eqx,"1",matrix);

           }
      else{
//alert("xn et yn");
nch_insert(eqx,eqy,matrix);


      }
   }

}
}


//calcu(7);
function calcux(c){
k="";
var d=0;
//alert(11%3==0);
s="1"

for(var i=1;i<c;i++){
    d=my_fact(c)/(my_fact(i)*my_fact(c-i));

    
            s=d+"x^"+i+","+s;
    
   
}
    s="1x^"+c+","+s;
sp=s.split(",");
return sp;
}
function calcuy(c){
k="";
var d=0;
s="1"

for(var i=1;i<c;i++){
    d=my_fact(c)/(my_fact(i)*my_fact(c-i));
   
          s=d+"y^"+i+","+s;
}
    s="1y^"+c+","+s;
    spy=s.split(",")
return spy;}
function my_fact($n)
{
    if($n==1)
    {
        return(1);
    }
    return(my_fact($n-1)*$n);
}

function nch_insert(X,Y,matrix){


var sig=0,yi=0,ry=0,py=0,vy=0,i=0,rx=0,vx=0,px=0,fx="",fy="",yy="";
var ty=new Array();
var tx=new Array();
var x="+",y="+",tst="";
while(yi<Y.length){

    ry=0;
if(Y[yi].includes("y^0")||!(Y[yi].includes("y^"))){
    ry=1;        // mettre au resultat -(x-1)^n doneés
}else{
ty=Y[yi].split("y^");
if(ty[0]==""){vy=""+y+""+1;}else{vy=""+y+""+ty[0];}
py=ty[1];
}
i=0;
while(i<X.length){

    if(( x=="-" && y== "+" )||( x=="+" && y=="-")){sig="-"}else{sig="+"}
    //alert(" sig  "+sig);

    if(X[i].includes("x^0")||!(X[i].includes("x^"))){
        rx=1;
        
    }else{
        tx=X[i].split("x^");
        if(tx[0]==""){vx=""+x+""+1;}else{vx=""+x+""+tx[0];};
        px=tx[1];        
    }
   // if(!X[i].includes("x^")){dx=tx[0];}
   //yy=Y[yi].split("")
  
if(ry==1){if(rx==1){resultat=sig+"1";}else{resultat=""+sig+""+X[i];}}
else{if(rx==1){resultat=""+sig+""+Y[yi];}else{resultat=vx*vy+"xy^"+px+","+py;}}
tst=tst+resultat+" | ";
//alert(tst);
i=i+1;
insert_matrice(resultat);
resultat="";
if(x=="-"){x="+";}
else{x="-";}
rx=0;
}
x="+";
if(y=="-"){y="+";}
else{y="-";}
yi=yi+1;
}

}

function insert_matrice(resultat){

if(resultat.includes("xy^")){
                    //            alert("c fait xy^");

        is=resultat.split("xy^");
        val=parseInt(is[0]);
        si=is[1].split(",");
        vlx=parseInt(si[0]);
        vly=parseInt(si[1]);
        matrix[vlx][vly]=val+matrix[vlx][vly];
                }
    else{
        if(resultat.includes("y^")){
                  //                      alert("c fait y^");

                    is=resultat.split("y^");
                    val=parseInt(is[0]);
                    vly=parseInt(is[1]);
                    matrix[0][vly]=val+matrix[0][vly];
    
        }
        else{ if(resultat.includes("x^")){
                 //           alert("c fait x^");

                    is=resultat.split("x^");
                    val=parseInt(is[0]);
                    //alert(val);
                    vlx=parseInt(is[1]);
                    //alert(matrix[3][0]);
                    matrix[vlx][0]=val+matrix[vlx][0];
               //     alert(matrix);
        }
            else{
                //alert("c fait 1");

                resultat=parseInt(resultat);
                matrix[0][0]=resultat+matrix[0][0];
            }
                  }
}
}

function matrix_0(H,W){
for ( var y = 0; y < H; y++ ) {
    matrix[ y ] = [];
    for ( var x = 0; x < W; x++ ) {
        matrix[ y ][ x ] = 0;
    }
}
}
//alert(matrix);
var equatio="";
//alert("mat : "+matrix+" nbsom : "+nbsom+" puissance x "+X+"  le Y : "+Y);
equ_tutte(matrix);
function equ_tutte(matrix){

for(var x=0;x<nbsom;x++){
  y=0;
while(y<nbsom){      
  if(matrix[x][y]!=0){
    equatio= equatio + "+"+matrix[x][y]+"(x^"+x+")(y^"+y+")";

  }
y=y+1;
  }

}
}

return equatio;


}
